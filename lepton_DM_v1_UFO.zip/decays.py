# This file was automatically created by FeynRules 2.3.43
# Mathematica version: 12.0.0 for Linux x86 (64-bit) (April 7, 2019)
# Date: Thu 18 Apr 2024 07:06:44


from object_library import all_decays, Decay
import particles as P


Decay_b = Decay(name = 'Decay_b',
                particle = P.b,
                partial_widths = {(P.W__minus__,P.t):'(((3*ee**2*MB**2)/(2.*sw**2) + (3*ee**2*MT**2)/(2.*sw**2) + (3*ee**2*MB**4)/(2.*MW**2*sw**2) - (3*ee**2*MB**2*MT**2)/(MW**2*sw**2) + (3*ee**2*MT**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MB**4 - 2*MB**2*MT**2 + MT**4 - 2*MB**2*MW**2 - 2*MT**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MB)**3)'})

Decay_dL__minus__ = Decay(name = 'Decay_dL__minus__',
                          particle = P.dL__minus__,
                          partial_widths = {(P.P__tilde__X,P.e__minus__):'((MdLm**2 - MDM**2)*(lamDM1*MdLm**2*complexconjugate(lamDM1) - lamDM1*MDM**2*complexconjugate(lamDM1)))/(32.*cmath.pi*abs(MdLm)**3)',
                                            (P.P__tilde__X,P.mu__minus__):'((MdLm**2 - MDM**2)*(lamDM2*MdLm**2*complexconjugate(lamDM2) - lamDM2*MDM**2*complexconjugate(lamDM2)))/(32.*cmath.pi*abs(MdLm)**3)',
                                            (P.P__tilde__X,P.ta__minus__):'((lamDM3*MdLm**2*complexconjugate(lamDM3) - lamDM3*MDM**2*complexconjugate(lamDM3) + lamDM3*MTA**2*complexconjugate(lamDM3))*cmath.sqrt(MdLm**4 - 2*MdLm**2*MDM**2 + MDM**4 - 2*MdLm**2*MTA**2 - 2*MDM**2*MTA**2 + MTA**4))/(32.*cmath.pi*abs(MdLm)**3)',
                                            (P.W__minus__,P.dN):'(((ee**2*MdLm**2)/sw**2 - (6*ee**2*MdLm*MdN)/sw**2 + (ee**2*MdN**2)/sw**2 + (ee**2*MdLm**4)/(MW**2*sw**2) - (2*ee**2*MdLm**2*MdN**2)/(MW**2*sw**2) + (ee**2*MdN**4)/(MW**2*sw**2) - (2*ee**2*MW**2)/sw**2)*cmath.sqrt(MdLm**4 - 2*MdLm**2*MdN**2 + MdN**4 - 2*MdLm**2*MW**2 - 2*MdN**2*MW**2 + MW**4))/(32.*cmath.pi*abs(MdLm)**3)'})

Decay_P__tilde__X = Decay(name = 'Decay_P__tilde__X',
                          particle = P.P__tilde__X,
                          partial_widths = {(P.dL__minus__,P.e__plus__):'((-MdLm**2 + MDM**2)*(-(lamDM1*MdLm**2*complexconjugate(lamDM1)) + lamDM1*MDM**2*complexconjugate(lamDM1)))/(16.*cmath.pi*abs(MDM)**3)',
                                            (P.dL__minus__,P.mu__plus__):'((-MdLm**2 + MDM**2)*(-(lamDM2*MdLm**2*complexconjugate(lamDM2)) + lamDM2*MDM**2*complexconjugate(lamDM2)))/(16.*cmath.pi*abs(MDM)**3)',
                                            (P.dL__minus__,P.ta__plus__):'((-(lamDM3*MdLm**2*complexconjugate(lamDM3)) + lamDM3*MDM**2*complexconjugate(lamDM3) - lamDM3*MTA**2*complexconjugate(lamDM3))*cmath.sqrt(MdLm**4 - 2*MdLm**2*MDM**2 + MDM**4 - 2*MdLm**2*MTA**2 - 2*MDM**2*MTA**2 + MTA**4))/(16.*cmath.pi*abs(MDM)**3)',
                                            (P.dN,P.ve__tilde__):'((MDM**2 - MdN**2)*(lamDM1*MDM**2*complexconjugate(lamDM1) - lamDM1*MdN**2*complexconjugate(lamDM1)))/(16.*cmath.pi*abs(MDM)**3)',
                                            (P.dN,P.vm__tilde__):'((MDM**2 - MdN**2)*(lamDM2*MDM**2*complexconjugate(lamDM2) - lamDM2*MdN**2*complexconjugate(lamDM2)))/(16.*cmath.pi*abs(MDM)**3)',
                                            (P.dN,P.vt__tilde__):'((MDM**2 - MdN**2)*(lamDM3*MDM**2*complexconjugate(lamDM3) - lamDM3*MdN**2*complexconjugate(lamDM3)))/(16.*cmath.pi*abs(MDM)**3)',
                                            (P.sL__minus__,P.e__plus__):'((MDM**2 - MsLm**2)*(kapDM1*MDM**2*complexconjugate(kapDM1) - kapDM1*MsLm**2*complexconjugate(kapDM1)))/(16.*cmath.pi*abs(MDM)**3)',
                                            (P.sL__minus__,P.mu__plus__):'((MDM**2 - MsLm**2)*(kapDM2*MDM**2*complexconjugate(kapDM2) - kapDM2*MsLm**2*complexconjugate(kapDM2)))/(16.*cmath.pi*abs(MDM)**3)',
                                            (P.sL__minus__,P.ta__plus__):'((kapDM3*MDM**2*complexconjugate(kapDM3) - kapDM3*MsLm**2*complexconjugate(kapDM3) - kapDM3*MTA**2*complexconjugate(kapDM3))*cmath.sqrt(MDM**4 - 2*MDM**2*MsLm**2 + MsLm**4 - 2*MDM**2*MTA**2 - 2*MsLm**2*MTA**2 + MTA**4))/(16.*cmath.pi*abs(MDM)**3)'})

Decay_dN = Decay(name = 'Decay_dN',
                 particle = P.dN,
                 partial_widths = {(P.P__tilde__X,P.ve):'((-MDM**2 + MdN**2)*(-(lamDM1*MDM**2*complexconjugate(lamDM1)) + lamDM1*MdN**2*complexconjugate(lamDM1)))/(32.*cmath.pi*abs(MdN)**3)',
                                   (P.P__tilde__X,P.vm):'((-MDM**2 + MdN**2)*(-(lamDM2*MDM**2*complexconjugate(lamDM2)) + lamDM2*MdN**2*complexconjugate(lamDM2)))/(32.*cmath.pi*abs(MdN)**3)',
                                   (P.P__tilde__X,P.vt):'((-MDM**2 + MdN**2)*(-(lamDM3*MDM**2*complexconjugate(lamDM3)) + lamDM3*MdN**2*complexconjugate(lamDM3)))/(32.*cmath.pi*abs(MdN)**3)',
                                   (P.W__plus__,P.dL__minus__):'(((ee**2*MdLm**2)/sw**2 - (6*ee**2*MdLm*MdN)/sw**2 + (ee**2*MdN**2)/sw**2 + (ee**2*MdLm**4)/(MW**2*sw**2) - (2*ee**2*MdLm**2*MdN**2)/(MW**2*sw**2) + (ee**2*MdN**4)/(MW**2*sw**2) - (2*ee**2*MW**2)/sw**2)*cmath.sqrt(MdLm**4 - 2*MdLm**2*MdN**2 + MdN**4 - 2*MdLm**2*MW**2 - 2*MdN**2*MW**2 + MW**4))/(32.*cmath.pi*abs(MdN)**3)'})

Decay_H = Decay(name = 'Decay_H',
                particle = P.H,
                partial_widths = {(P.b,P.b__tilde__):'((-12*MB**2*yb**2 + 3*MH**2*yb**2)*cmath.sqrt(-4*MB**2*MH**2 + MH**4))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.t,P.t__tilde__):'((3*MH**2*yt**2 - 12*MT**2*yt**2)*cmath.sqrt(MH**4 - 4*MH**2*MT**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.ta__minus__,P.ta__plus__):'((MH**2*ytau**2 - 4*MTA**2*ytau**2)*cmath.sqrt(MH**4 - 4*MH**2*MTA**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.W__minus__,P.W__plus__):'(((3*ee**4*vev**2)/(4.*sw**4) + (ee**4*MH**4*vev**2)/(16.*MW**4*sw**4) - (ee**4*MH**2*vev**2)/(4.*MW**2*sw**4))*cmath.sqrt(MH**4 - 4*MH**2*MW**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.Z,P.Z):'(((9*ee**4*vev**2)/2. + (3*ee**4*MH**4*vev**2)/(8.*MZ**4) - (3*ee**4*MH**2*vev**2)/(2.*MZ**2) + (3*cw**4*ee**4*vev**2)/(4.*sw**4) + (cw**4*ee**4*MH**4*vev**2)/(16.*MZ**4*sw**4) - (cw**4*ee**4*MH**2*vev**2)/(4.*MZ**2*sw**4) + (3*cw**2*ee**4*vev**2)/sw**2 + (cw**2*ee**4*MH**4*vev**2)/(4.*MZ**4*sw**2) - (cw**2*ee**4*MH**2*vev**2)/(MZ**2*sw**2) + (3*ee**4*sw**2*vev**2)/cw**2 + (ee**4*MH**4*sw**2*vev**2)/(4.*cw**2*MZ**4) - (ee**4*MH**2*sw**2*vev**2)/(cw**2*MZ**2) + (3*ee**4*sw**4*vev**2)/(4.*cw**4) + (ee**4*MH**4*sw**4*vev**2)/(16.*cw**4*MZ**4) - (ee**4*MH**2*sw**4*vev**2)/(4.*cw**4*MZ**2))*cmath.sqrt(MH**4 - 4*MH**2*MZ**2))/(32.*cmath.pi*abs(MH)**3)'})

Decay_sL__minus__ = Decay(name = 'Decay_sL__minus__',
                          particle = P.sL__minus__,
                          partial_widths = {(P.P__tilde__X,P.e__minus__):'((-MDM**2 + MsLm**2)*(-(kapDM1*MDM**2*complexconjugate(kapDM1)) + kapDM1*MsLm**2*complexconjugate(kapDM1)))/(32.*cmath.pi*abs(MsLm)**3)',
                                            (P.P__tilde__X,P.mu__minus__):'((-MDM**2 + MsLm**2)*(-(kapDM2*MDM**2*complexconjugate(kapDM2)) + kapDM2*MsLm**2*complexconjugate(kapDM2)))/(32.*cmath.pi*abs(MsLm)**3)',
                                            (P.P__tilde__X,P.ta__minus__):'((-(kapDM3*MDM**2*complexconjugate(kapDM3)) + kapDM3*MsLm**2*complexconjugate(kapDM3) + kapDM3*MTA**2*complexconjugate(kapDM3))*cmath.sqrt(MDM**4 - 2*MDM**2*MsLm**2 + MsLm**4 - 2*MDM**2*MTA**2 - 2*MsLm**2*MTA**2 + MTA**4))/(32.*cmath.pi*abs(MsLm)**3)'})

Decay_t = Decay(name = 'Decay_t',
                particle = P.t,
                partial_widths = {(P.W__plus__,P.b):'(((3*ee**2*MB**2)/(2.*sw**2) + (3*ee**2*MT**2)/(2.*sw**2) + (3*ee**2*MB**4)/(2.*MW**2*sw**2) - (3*ee**2*MB**2*MT**2)/(MW**2*sw**2) + (3*ee**2*MT**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MB**4 - 2*MB**2*MT**2 + MT**4 - 2*MB**2*MW**2 - 2*MT**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MT)**3)'})

Decay_ta__minus__ = Decay(name = 'Decay_ta__minus__',
                          particle = P.ta__minus__,
                          partial_widths = {(P.P__tilde__X__tilde__,P.dL__minus__):'((lamDM3*MdLm**2*complexconjugate(lamDM3) - lamDM3*MDM**2*complexconjugate(lamDM3) + lamDM3*MTA**2*complexconjugate(lamDM3))*cmath.sqrt(MdLm**4 - 2*MdLm**2*MDM**2 + MDM**4 - 2*MdLm**2*MTA**2 - 2*MDM**2*MTA**2 + MTA**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.P__tilde__X__tilde__,P.sL__minus__):'((-(kapDM3*MDM**2*complexconjugate(kapDM3)) + kapDM3*MsLm**2*complexconjugate(kapDM3) + kapDM3*MTA**2*complexconjugate(kapDM3))*cmath.sqrt(MDM**4 - 2*MDM**2*MsLm**2 + MsLm**4 - 2*MDM**2*MTA**2 - 2*MsLm**2*MTA**2 + MTA**4))/(32.*cmath.pi*abs(MTA)**3)',
                                            (P.W__minus__,P.vt):'((MTA**2 - MW**2)*((ee**2*MTA**2)/(2.*sw**2) + (ee**2*MTA**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2))/(32.*cmath.pi*abs(MTA)**3)'})

Decay_W__plus__ = Decay(name = 'Decay_W__plus__',
                        particle = P.W__plus__,
                        partial_widths = {(P.c,P.s__tilde__):'(ee**2*MW**4)/(16.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.dN,P.dL__plus__):'((-((ee**2*MdLm**2)/sw**2) + (6*ee**2*MdLm*MdN)/sw**2 - (ee**2*MdN**2)/sw**2 - (ee**2*MdLm**4)/(MW**2*sw**2) + (2*ee**2*MdLm**2*MdN**2)/(MW**2*sw**2) - (ee**2*MdN**4)/(MW**2*sw**2) + (2*ee**2*MW**2)/sw**2)*cmath.sqrt(MdLm**4 - 2*MdLm**2*MdN**2 + MdN**4 - 2*MdLm**2*MW**2 - 2*MdN**2*MW**2 + MW**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.t,P.b__tilde__):'(((-3*ee**2*MB**2)/(2.*sw**2) - (3*ee**2*MT**2)/(2.*sw**2) - (3*ee**2*MB**4)/(2.*MW**2*sw**2) + (3*ee**2*MB**2*MT**2)/(MW**2*sw**2) - (3*ee**2*MT**4)/(2.*MW**2*sw**2) + (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MB**4 - 2*MB**2*MT**2 + MT**4 - 2*MB**2*MW**2 - 2*MT**2*MW**2 + MW**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.u,P.d__tilde__):'(ee**2*MW**4)/(16.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.ve,P.e__plus__):'(ee**2*MW**4)/(48.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.vm,P.mu__plus__):'(ee**2*MW**4)/(48.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.vt,P.ta__plus__):'((-MTA**2 + MW**2)*(-(ee**2*MTA**2)/(2.*sw**2) - (ee**2*MTA**4)/(2.*MW**2*sw**2) + (ee**2*MW**2)/sw**2))/(48.*cmath.pi*abs(MW)**3)'})

Decay_Z = Decay(name = 'Decay_Z',
                particle = P.Z,
                partial_widths = {(P.b,P.b__tilde__):'((-7*ee**2*MB**2 + ee**2*MZ**2 - (3*cw**2*ee**2*MB**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) - (17*ee**2*MB**2*sw**2)/(6.*cw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MB**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.c,P.c__tilde__):'(MZ**2*(-(ee**2*MZ**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.d,P.d__tilde__):'(MZ**2*(ee**2*MZ**2 + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.dL__minus__,P.dL__plus__):'((-4*ee**2*MdLm**2 - 2*ee**2*MZ**2 + (2*cw**2*ee**2*MdLm**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 + (2*ee**2*MdLm**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MdLm**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.dN,P.dN__tilde__):'((4*ee**2*MdN**2 + 2*ee**2*MZ**2 + (2*cw**2*ee**2*MdN**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 + (2*ee**2*MdN**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MdN**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.e__minus__,P.e__plus__):'(MZ**2*(-(ee**2*MZ**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.mu__minus__,P.mu__plus__):'(MZ**2*(-(ee**2*MZ**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.s,P.s__tilde__):'(MZ**2*(ee**2*MZ**2 + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.sL__minus__,P.sL__plus__):'(((8*ee**2*MsLm**2*sw**2)/cw**2 + (4*ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*MsLm**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.t,P.t__tilde__):'((-11*ee**2*MT**2 - ee**2*MZ**2 - (3*cw**2*ee**2*MT**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MT**2*sw**2)/(6.*cw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MT**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ta__minus__,P.ta__plus__):'((-5*ee**2*MTA**2 - ee**2*MZ**2 - (cw**2*ee**2*MTA**2)/(2.*sw**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MTA**2*sw**2)/(2.*cw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*MTA**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.u,P.u__tilde__):'(MZ**2*(-(ee**2*MZ**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ve,P.ve__tilde__):'(MZ**2*(ee**2*MZ**2 + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.vm,P.vm__tilde__):'(MZ**2*(ee**2*MZ**2 + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.vt,P.vt__tilde__):'(MZ**2*(ee**2*MZ**2 + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.W__minus__,P.W__plus__):'(((-12*cw**2*ee**2*MW**2)/sw**2 - (17*cw**2*ee**2*MZ**2)/sw**2 + (4*cw**2*ee**2*MZ**4)/(MW**2*sw**2) + (cw**2*ee**2*MZ**6)/(4.*MW**4*sw**2))*cmath.sqrt(-4*MW**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)'})

